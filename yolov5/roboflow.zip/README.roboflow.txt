
YoloV5l6 - v10 Balanceada v7
==============================

This dataset was exported via roboflow.ai on November 5, 2021 at 8:03 PM GMT

It includes 6391 images.
Persons are annotated in YOLO v5 PyTorch format.

The following pre-processing was applied to each image:
* Resize to 200x200 (Stretch)

No image augmentation techniques were applied.


